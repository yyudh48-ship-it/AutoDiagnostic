AutoDiagnostic — Project By Yudha Prawira

Untuk membuat APK:
- Unggah seluruh isi paket ini ke root repository GitHub.
- Buka Actions > Build AutoDiagnostic APK > Run workflow.
- Setelah workflow selesai, unduh artifact AutoDiagnostic-APK.

Petunjuk lengkap ada di PETUNJUK_BUILD_APK_DARI_HP.txt.
Android source ada di folder android/.
Web/offline prototype ada di folder web/.
